 <!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4" style="background:none;">
                    	 <h1 class="text-uppercase text-white font-weight-bold">About Us</h1>
                        <hr class="divider my-4" />
                    </div>
                    
                </div>
            </div>
        </header>
<title>Doctor's appointment system</title>
    <section class="page-section">
        <div class="container con-con">
    <?php   echo html_entity_decode($_SESSION['setting_about_content']); ?>        
            
        </div>
        </section>