<?php include'db_connect.php' ?>

<style>
/* Add background gradient for the page */
body {
    background: linear-gradient(50deg,rgba(39, 241, 238, 0.59)	, #f1243234);
    font-family: 'Arial', sans-serif;
}

/* Card Container - Add some space between cards */
.card {
    margin-bottom: 20px;
    border-radius: 15px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.91);
    transition: transform 0.3s ease-in-out, box-shadow 0.3s ease;
}

/* Hover Effect for Cards */
.card:hover {
    transform: translateY(-10px);  /* Slight lift effect */
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3); /* Stronger shadow */
}

/* Card Body Styling */
.card-body {
    padding: 30px;
}

/* Add smooth fade-in for the page elements */
.row {
    opacity: 0;
    animation: fadeIn 1s forwards;
    animation-delay: 0.5s;
}

@keyframes fadeIn {
    to {
        opacity: 1;
    }
}

/* Customize card titles and icons */
.card h4 {
    font-size: 24px;
    font-weight: bold;
    letter-spacing: 1px;
}

/* Icon styles */
.summary_icon {
    font-size: 40px;
}

/* Links Styling */
.list-group-item-action {
    transition: background-color 0.3s ease;
}

.list-group-item-action:hover {
    background-color: rgba(0, 0, 0, 0.1);
}

/* Floating arrow icon */
.float-sm-right {
    position: relative;
    top: 3px;
    transition: transform 0.3s;
}

.list-group-item-action:hover .float-sm-right {
    transform: translateX(5px);
}

/* Responsive Tweaks */
@media (max-width: 768px) {
    .col-md-4 {
        margin-bottom: 15px;
    }
    .card-body {
        padding: 20px;
    }
}
</style>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card text-white bg-info">
                <div class="card-body text-white">
                    <h4><span class="float-right summary_icon"><i class="fa fa-users"></i></span>
					<b><?php echo $conn->query("SELECT * FROM users")->num_rows; ?></b></h4>
			        <b>Users</b>   
                </div>
				
				<div class="list-group-item-info list-group-item list-group-item-action">
					<div class="row">
						<div class="col-sm-8">
							<p class="">view info</p>
						</div>
						<div class="col-sm-4">
							<a href="index.php?page=users"><i class="fa fa-arrow-right float-sm-right"></i></a>
						</div>
                    </div>
                </div>
            </div>
		</div>
	</div>
	
	<div class="col-md-4">
        <div class="card">
            <div class="card text-white bg-success">
                <div class="card-body text-white">
                    <h4><span class="float-right summary_icon"><i class="fa fa-user-md"></i></span>
                    <b>
					<?php echo $conn->query("SELECT * FROM users where type=2")->num_rows; ?></b></h4>
			        <b>Doctors</b>   
                </div>
				
				<div class="list-group-item-success list-group-item list-group-item-action">
					<div class="row">
						<div class="col-sm-8">
							<p class="">view info</p>
						</div>
						<div class="col-sm-4">
							<a href="index.php?page=doctors"><i class="fa fa-arrow-right float-sm-right"></i></a>
						</div>
                    </div>
                </div>
            </div>
		</div>
	</div>
	
	<div class="col-md-4">
        <div class="card">
            <div class="card text-white bg-secondary">
                <div class="card-body text-white">
                    <h4><span class="float-right summary_icon"><i class="fa fa-calendar"></i></span>
                    <b>
					<?php echo $conn->query("SELECT * FROM appointment_list")->num_rows; ?></b></h4>
			        <b>Appointments</b>   
                </div>
				
				<div class="list-group-item-secondary list-group-item list-group-item-action">
					<div class="row">
						<div class="col-sm-8">
							<p class="">view info</p>
						</div>
						<div class="col-sm-4">
							<a href="index.php?page=appointments"><i class="fa fa-arrow-right float-sm-right"></i></a>
						</div>
                    </div>
                </div>
            </div>
		</div>
	</div>
	
	<div class="col-md-4">
        <div class="card">
            <div class="card text-white bg-warning">
                <div class="card-body text-white">
                    <h4><span class="float-right summary_icon"><i class="fa fa-comments"></i></span>
                    <b>
					<?php echo $conn->query("SELECT * FROM feedback")->num_rows; ?></b></h4>  
			        <b>Feedback</b> 
                </div>
				
				<div class="list-group-item-warning list-group-item list-group-item-action">
					<div class="row">
						<div class="col-sm-8">
							<p class="">view info</p>
						</div>
						<div class="col-sm-4">
							<a href="index.php?page=view_feedback"><i class="fa fa-arrow-right float-sm-right"></i></a>
						</div>
                    </div>
                </div>
            </div>
		</div>
	</div>
</div>
				
                        