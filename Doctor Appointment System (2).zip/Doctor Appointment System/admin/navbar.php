
<style>
</style>
<nav id="sidebar" class='mx-lt-5 bg-dark' >
		
		<div class="sidebar-list">
				<?php  if($_SESSION['login_type'] == 1): ?>
					<a href="index.php?page=home" class="nav-item nav-home"><span class='icon-field'><i class="fa fa-home"></i></span> Home</a>
					<a href="index.php?page=dashboard" class="nav-item nav-dashboard"><span class='icon=field'><i class="fas fa-tachometer-alt"></i></span> Dashboard</a>
					<a href="index.php?page=appointments" class="nav-item nav-appointments"><span class='icon-field'><i class="fa fa-calendar"></i></span> Appointments</a>
					<a href="index.php?page=doctors" class="nav-item nav-doctors"><span class='icon-field'><i class="fa fa-user-md"></i></span> Doctors</a>
					<a href="index.php?page=categories" class="nav-item nav-categories"><span class='icon-field'><i class="fa fa-book-medical"></i></span> Medical Specialties</a>			
					<a href="index.php?page=users" class="nav-item nav-users"><span class='icon-field'><i class="fa fa-users"></i></span> Users</a>
					<a href="index.php?page=view_feedback" class="nav-item nav-view_feedback"><span class='icon-field'><i class="fa fa-comments"></i></span> view feedback</a>
					<a href="index.php?page=site_settings" class="nav-item nav-site_settings"><span class='icon-field'><i class="fa fa-cog"></i></span> Site Settings</a>
				<?php endif; ?>
				<?php if($_SESSION['login_type'] == 2): ?>
	                <a href="index.php?page=home" class="nav-item nav-home"><span class='icon-field'><i class="fa fa-home"></i></span> Home</a>
					<a href="index.php?page=appointments" class="nav-item nav-appointments"><span class='icon-field'><i class="fa fa-calendar"></i></span> Appointments</a>
					<a href="index.php?page=changepwd" class="nav-item nav-changepwd"><span class='icon-field'><i class="fa fa-key"></i></span> Change Password</a>
					<a href="index.php?page=my_details" class="nav-item nav-my_details"><span class='icon-field'><i class="fa fa-user"></i></span> My Details</a>
				<?php endif ?>
		</div>

</nav>
<script>
	$('.nav-<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>').addClass('active')
</script>
