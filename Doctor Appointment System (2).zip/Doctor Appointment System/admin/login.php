<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin | Doctor's Appointment System</title>
 	

<?php include('./header.php'); ?>
<?php include('./db_connect.php'); ?>
<?php if(isset($_SESSION['login_id'])) header("location:index.php?page=home"); ?>

</head>
<style>
	body
	{
		width: 100%;
	    height: calc(100%);
		background: rgba(256,256,256,0.5);
	}
	main#main
	{
		width:100%;
		height: calc(100%);
		background:white;
	}
	#login-right
	{
		position: absolute;
		right:0;
		width:40%;
		height: calc(100%);
		background:lavender;
		display: flex;
		align-items: center;
	}
	#login-left
	{
		position: absolute;
		left:0;
		width:60%;
		height: calc(100%);	
		display: flex;
		align-items: center;
		background: url(../assets/img/bg/download.jpg);
	    background-repeat: no-repeat;
	    background-size: cover;
	}
	#login-right .card
	{
		margin: auto
	}
	.logo
	{
		margin: auto;
		font-size: 8rem;
   
		background:rgba(0,0,255,0.2);
		padding: .5em 0.7em;
		border-radius: 50% 50%;
		color:black;
	}
	

</style>

<body>


  <main id="main" class=" bg-dark">
  		<div id="login-left">
  			<div class="logo">
  				<span class="fa fa-laptop-medical"></span>
  			</div>
  		</div>
  		<div id="login-right">
  			<div class="card col-md-8">
  				<div class="card-body">
  					<form id="login-form" action="#" method="post"  >
						<div class="form-group">
							<center><img align="center" src="logo.png"></img></center>
						</div>
  						<div class="form-group">
  							<label for="username"  class="control-label">Username</label>
  							<input type="text" name="username" id="username" name="username" class="form-control">
  						</div>
  						<div class="form-group">
  							<label for="password" class="control-label">Password</label>
  							<input type="password" name="password" id="password" name="password" class="form-control">
  						</div>
  						<center><button class="btn-sm btn-block btn-wave col-md-4 btn-primary"name="loginfrm">Login</button></center>
  					</form>
  				</div>
  			</div>
  		</div>
   

  </main>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>


</body>
<script>
	 $('#login-form').submit(function(e){
	 	e.preventDefault()
	 	$('#login-form button[type="button"]').attr('disabled',true).html('Logging in...');
	 	if($(this).find('.alert-danger').length > 0 )
	 		$(this).find('.alert-danger').remove();
	 	$.ajax({
	 		url:'ajax.php?action=login',
	 		method:'POST',
	 		data:$(this).serialize(),
	 		error:err=>{
	 			console.log(err)
	 	$('#login-form button[type="button"]').removeAttr('disabled').html('Login')
	 		},
	 		success:function(resp){
	 			if(resp == 1){
	 				location.href ='index.php?page=home';
	 			}else if(resp == 2){
	 				location.href ='voting.php';
	 			}else{
	 				$('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
	 				$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
	 			}
	 		}
	 	})
	 })
	 $('#login-form').submit(function(e){
	 	e.preventDefault()
	 	$('#login-form button[type="button"]').attr('disabled',true).html('Logging in...');
	 	if($(this).find('.alert-danger').length > 0 )
	 		$(this).find('.alert-danger').remove();
	 	$.ajax({
	 		url:'ajax.php?action=login3',
	 		method:'POST',
	 		data:$(this).serialize(),
	 		error:err=>{
	 			console.log(err)
	 	$('#login-form button[type="button"]').removeAttr('disabled').html('Login')
	 		},
	 		success:function(resp){
	 			if(resp == 1){
	 				location.href ='index.php?page=home';
	 			}else if(resp == 2){
	 				location.href ='voting.php';
	 			}else{
	 				//$('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
	 				$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
	 			}
	 		}
	 	})
	 })
</script>	
</html>